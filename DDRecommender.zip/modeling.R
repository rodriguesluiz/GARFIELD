library(readxl)
ds <- read_excel("dataset exp 2021-1.xlsx")
colnames(ds)

table(ds$status)
table(ds$session)
ds <- ds[(ds$status != "Didn't use") & (ds$session == 0) 
         & (ds$gender != "Rather not say"), ]

ds$gender <- factor(ds$gender)
table(ds$gender)

ds$educationlevel <- factor(ds$educationlevel)
levels(ds$educationlevel) <- c("High school", "Technical", "Technical", "High school",              
                               "Undergraduation")
table(ds$educationlevel)

ds$prefgamegenre <- factor(ds$prefgamegenre)
levels(ds$prefgamegenre)
levels(ds$prefgamegenre) <- c("Action", "Other", "Adventure", "Other", "Other", 
                              "Other", "RPG", "Other", "Other", "Strategy")
table(ds$prefgamegenre)
ds <- ds[ds$prefgamegenre != "Other", ]
ds$prefgamegenre <- factor(ds$prefgamegenre)

ds$motivated <- factor(ds$intrinsic_motivation > 5)

table(ds$game_elements)
#ds <- ds[ds$game_elements != "CCT", ]
prop.table(table(ds$game_elements))
ds$game_elements <- factor(ds$game_elements)
ds$game_elements <- relevel(ds$game_elements, ref = "PBL")

library(nnet)
mdl <- multinom(game_elements ~ (intrinsic_motivation) * 
                  (prefgamegenre + prefplayingsetting + weeklyplayingtime
                   + age + gender + educationlevel), 
                data = ds, maxit = 1000)
predict(mdl, ds)
save(mdl, file = "recmodel.rda")